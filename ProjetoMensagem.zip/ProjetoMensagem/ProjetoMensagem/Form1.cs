﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class FrmEnvioMensagem : Form
    {
        public FrmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão Mostrar click");
        }

        private void FrmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Formulário Aberto");

        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Texto Decimal");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Texto Inteiro");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Texto");
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Texto Booleano");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão limpar click");
        }
    }
}
