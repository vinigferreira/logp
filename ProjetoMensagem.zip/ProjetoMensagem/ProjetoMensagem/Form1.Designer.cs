﻿namespace ProjetoMensagem
{
    partial class FrmEnvioMensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDecimal = new System.Windows.Forms.Label();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblBooleano = new System.Windows.Forms.Label();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtBooleano = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.Location = new System.Drawing.Point(64, 81);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(89, 25);
            this.lblDecimal.TabIndex = 0;
            this.lblDecimal.Text = "Decimal";
            this.lblDecimal.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(50, 288);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(103, 42);
            this.btnMostrar.TabIndex = 1;
            this.btnMostrar.Text = "MOSTRAR";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(171, 288);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(103, 42);
            this.btnLimpar.TabIndex = 2;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.Location = new System.Drawing.Point(64, 132);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(71, 25);
            this.lblInteiro.TabIndex = 3;
            this.lblInteiro.Text = "Inteiro";
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(64, 183);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(66, 25);
            this.lblTexto.TabIndex = 4;
            this.lblTexto.Text = "Texto";
            // 
            // lblBooleano
            // 
            this.lblBooleano.AutoSize = true;
            this.lblBooleano.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBooleano.Location = new System.Drawing.Point(64, 234);
            this.lblBooleano.Name = "lblBooleano";
            this.lblBooleano.Size = new System.Drawing.Size(103, 25);
            this.lblBooleano.TabIndex = 5;
            this.lblBooleano.Text = "Booleano";
            this.lblBooleano.Click += new System.EventHandler(this.lblBooleano_Click);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(65, 109);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(197, 20);
            this.txtDecimal.TabIndex = 6;
            this.txtDecimal.TextChanged += new System.EventHandler(this.txtDecimal_TextChanged);
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(65, 160);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(197, 20);
            this.txtInteiro.TabIndex = 7;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(65, 211);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(197, 20);
            this.txtTexto.TabIndex = 8;
            this.txtTexto.TextChanged += new System.EventHandler(this.txtTexto_TextChanged);
            // 
            // txtBooleano
            // 
            this.txtBooleano.Location = new System.Drawing.Point(65, 262);
            this.txtBooleano.Name = "txtBooleano";
            this.txtBooleano.Size = new System.Drawing.Size(197, 20);
            this.txtBooleano.TabIndex = 9;
            // 
            // FrmEnvioMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(335, 426);
            this.Controls.Add(this.txtBooleano);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.lblBooleano);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.lblDecimal);
            this.Name = "FrmEnvioMensagem";
            this.Text = "Z\'";
            this.Load += new System.EventHandler(this.FrmEnvioMensagem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblBooleano;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtBooleano;
    }
}

