﻿using System;
using System.Windows.Forms;

namespace FormCalculadora
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void frmCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            float varnumero1 = float.Parse(txtnumero1.Text);
            float varnumero2 = float.Parse(txtnumero2.Text);
            float soma;
            soma = varnumero1 + varnumero2;
            MessageBox.Show("O resultado é:" + soma);
        }

        private void btnmultiplicacao_Click(object sender, EventArgs e)
        {
            float varnumero1 = float.Parse(txtnumero1.Text);
            float varnumero2 = float.Parse(txtnumero2.Text);
            float multiplicacao;
                multiplicacao = varnumero1 * varnumero2;
            MessageBox.Show("O resultado é:" + multiplicacao);

        }

        private void btnsubtracao_Click(object sender, EventArgs e)
        {
            float varnumero1 = float.Parse(txtnumero1.Text);
            float varnumero2 = float.Parse(txtnumero2.Text);
            float subtracao;
            subtracao = varnumero1 - varnumero2;
            MessageBox.Show("O resultado é:" + subtracao);
        }

        private void btndivisao_Click(object sender, EventArgs e)
        {
            float varnumero1 = float.Parse(txtnumero1.Text);
            float varnumero2 = float.Parse(txtnumero2.Text);
            float divisao;
            divisao = varnumero1 / varnumero2;
            MessageBox.Show("O resultado é:" + divisao);
        }
    }
}
